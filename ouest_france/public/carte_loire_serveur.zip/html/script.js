var BASE_FONT = "'Helvetica Neue', Helvetica, Arial, sans-serif";

var FONTS = [
  "Open Sans",
  "Josefin Slab",
  "Arvo",
  "Lato",
  "Vollkorn",
  "Abril Fatface",
  "Old StandardTT",
  "Droid+Sans",
  "Lobster",
  "Inconsolata",
  "Montserrat",
  "Playfair Display",
  "Karla",
  "Alegreya",
  "Libre Baskerville",
  "Merriweather",
  "Lora",
  "Archivo Narrow",
  "Neuton",
  "Signika",
  "Questrial",
  "Fjalla One",
  "Bitter",
  "Varela Round"
];

var cities = [
  ["Nantes", 546, 241],
  ["Pornic", 402, 272],
  ["Guérande", 325, 205],
  ["Ancenis", 661, 177],
  ["Chateaubriant", 585, 39]
];

var width = 960,
    height = 500,
    centered;

// Define color scale
var color = d3.scale.linear()
  .domain([1, 20])
  .clamp(true)
  .range(['#6666ff', '#6666ff']);

var projection = d3.geo.mercator()
  .scale(2000)
  // Center the Map in Colombia
  .center([-74, 1.5])
  .translate([width / 2, height / 2]);

var path = d3.geo.path()
  .projection(projection);

// Set svg width & height
var svg = d3.select('svg')
  .attr('width', width)
  .attr('height', height);

// Add background
svg.append('rect')
  .attr('class', 'background')
  .attr('width', width)
  .attr('height', height)
  .on('click', clicked);

var g = svg.append('g');

var mapLayer = g.append('g')
  .classed('map-layer', true);

var actualZone = "";
var zoneBackgroundSize = [80, 40];
var iconCrossSize = [8, 8];
var zoneState = 0;
var zone0 = "", zone1 = "";
var zone0Loc = [100, 200], zone1Loc = [100, 230];

var defaultFontFamily = FONTS[0] + ', ' + BASE_FONT;

var cross0Image = svg.append("svg:image")
      .classed('hiddenCross', true)
      .attr('x', zone0Loc[0] + zoneBackgroundSize[0] - iconCrossSize[0]/2)
      .attr('y', zone0Loc[1] - iconCrossSize[1])
      .attr('width', iconCrossSize[0])
      .attr('height', iconCrossSize[1])
      .attr("xlink:href", "cross.png");

var cross1Image = svg.append("svg:image")
      .classed('hiddenCross', true)
      .attr('x', zone1Loc[0] + zoneBackgroundSize[0] - iconCrossSize[0]/2)
      .attr('y', zone1Loc[1] - iconCrossSize[1])
      .attr('width', iconCrossSize[0])
      .attr('height', iconCrossSize[1])
      .attr("xlink:href", "cross.png");

var zone0Text = g.append('text')
      .classed('big-text', true)
      .style('font-family', defaultFontFamily)
      .style("font-size", "14px")
      .attr('x', zone0Loc[0])
      .attr('y', zone0Loc[1])
      .attr("unselectable", "on");

var zone1Text = g.append('text')
      .classed('big-text', true)
      .style('font-family', defaultFontFamily)
      .style("font-size", "14px")
      .attr('x', zone1Loc[0])
      .attr('y', zone1Loc[1])
      .attr("unselectable", "on");

var bigText = g.append('text')
  .classed('big-text', true)
  .attr('x', 20)
  .attr('y', 45)
  .attr("unselectable", "on");

// Display cities
function displayCities() {
  var fontFamily = FONTS[0] + ', ' + BASE_FONT;
  for (var i=0; i<cities.length; i++) {

    var icon_width = 8;
    var icon_height = 8;

    var text = cities[i][0];
    var city_x = cities[i][1];
    var city_y = cities[i][2];
    
    svg.append("svg:image")
      .classed('notSelectable', true)
      .attr('x', city_x - icon_width/2)
      .attr('y', city_y - icon_height)
      .attr('width', icon_width)
      .attr('height', icon_height)
      .attr("xlink:href", "dot.png");

    var text = g.append('text')
      .classed('big-text', true)
      .style('font-family', fontFamily)
      .style("font-size", "14px")
      .text(text)
      .attr("unselectable", "on");

    // determine text size
    var bbox = text.node().getBBox();
    
    var textWidth = bbox.width;
    var textHeight = bbox.height;

    text.attr('x', city_x - textWidth/2)
      .attr('y', city_y + textHeight)
  }
}

displayCities();

// Load map data
//edgt30_simp32_transformed.geo.json
d3.json('edgt30_simp32_transformed.geo.json', function(error, mapData) {
  var features = mapData.features;

  // Update color scale domain based on data
  color.domain([0, d3.max(features, nameLength)]);

  // Draw each province as a path
  mapLayer.selectAll('path')
      .data(features)
    .enter().append('path')
      .attr('d', path)
      .attr('vector-effect', 'non-scaling-stroke')
      .style('fill', fillFn)
      .on('mouseover', mouseover)
      .on('mouseout', mouseout)
      .on('click', clicked);
});

// Get province name
function nameFn(d){
  return d && d.properties ? d.properties.libgeo : null;
}

// Get province name length
function nameLength(d){
  var n = nameFn(d);
  return n ? n.length : 0;
}

// Get province color
function fillFn(d){
  return color(nameLength(d));
}

function clicked(d) {
  if (actualZone.localeCompare("") == 0)
    return;

  switch (zoneState) {
    case 0:
      zone0 = actualZone;
      zoneState++;
      cross0Image.classed('cross', true).classed('hiddenCross', false);
      cross0Image.on('click', unclicked0);
      if (zone1.localeCompare("") != 0) {
        zoneState++;
      }
      break;
    case 1:
      zone1 = actualZone;
      zoneState++;
      cross1Image.classed('cross', true).classed('hiddenCross', false);;
      cross1Image.on('click', unclicked1)
      break;
  }
}

function unclicked0(d) {
  zone0 = "";
  zoneState = 0;
  zone0Text.text("");
  cross0Image.classed('cross', false).classed('hiddenCross', true);
  cross0Image.on('click', null);
}

function unclicked1(d) {
  zone1 = "";
  zoneState = (zoneState < 1) ? zoneState : 1;
  zone1Text.text("");
  cross1Image.classed('cross', false).classed('hiddenCross', true);
  cross1Image.on('click', null);
}

function mouseover(d){  
  // Highlight hovered province
  d3.select(this).style('fill', 'orange');

  // Draw effects
  updateZoneText(nameFn(d));
}

function mouseout(d){
  // Reset province color
  mapLayer.selectAll('path')
    .style('fill', function(d){return centered && d===centered ? '#D5708B' : fillFn(d);});

  updateZoneText("");
}

function updateZoneText(text) {

  actualZone = text;
  var myText, loc;
  switch (zoneState) {
    case 0:
      zone0 = text;
      myText = zone0Text;
      loc = zone0Loc;
      break;
    case 1:
      zone1 = text;
      myText = zone1Text;
      loc = zone1Loc;
      break;
    default:
      return;
  }

  // Change text
  myText.text(text);

  // Compute text size
  var bbox = myText.node().getBBox();
  var textWidth = bbox.width;

  // Update text to center
  myText.attr('x', loc[0] - textWidth/2);
}

function myTextArt(data) {
  // Use random font
  var fontIndex = 0;
  var fontFamily = FONTS[fontIndex] + ', ' + BASE_FONT;

  x = width / 2;
  y = height - 20;

  var text = nameFn(data);

  bigText
    .style('font-family', fontFamily)
    .text(text)
    .style('opacity', 0);
  
  var bbox = bigText.node().getBBox();
  
  var textWidth = bbox.width;
  var textHeight = bbox.height;

  bigText.attr('x', x - textWidth/2)
    .attr('y', y);

  bigText.transition()
    .style('opacity', function(d){
      return 1.0;
    })
    .attr("y", y - 10)
    .duration(170)
}



